#!/bin/sh
printf '\033c\033]0;%s\a' CornKeeper
base_path="$(dirname "$(realpath "$0")")"
"$base_path/CornKeeper.x86_64" "$@"
